library(RTextTools)
library(e1071)

data<-read.csv("Redmiflipkart_trainingdataset.csv")
table(data$review)
tdata<-sample(2,nrow(data),replace = FALSE,prob=c(0.67,0.33))
trainD<-data[tdata==1,]
testD<-data[tdata==2,]
trainD
nrow(trainD)
nrow(testD)
print("***********")
testD
library(rminer)
model1<-naiveBayes(class ~ .,data=trainD)

#print("******************************************************************")
predict11<-predict(model1,testD)
predict11
mmetric(testD$class,predict11,c("ACC","PRECISION","TPR","F1"))
testdata<-as.vector(testD$class,mode="character")
obtres<-as.vector(predict11,mode="character")
cnt<-0
for(i in 1:length(testdata))
{
  if(testdata[i]=="positive"&&obtres=="positive")
    cnt=cnt+1
}
p_per=cnt/length(testdata)
n_per=1-p_per
print(p_per)
print(n_per)
c<-c(p_per,n_per)
pie(c,col = c("red","blue"))


